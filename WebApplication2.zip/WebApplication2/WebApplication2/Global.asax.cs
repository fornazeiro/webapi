﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Routing;

namespace WebApplication2
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            //GlobalConfiguration.Configure(WebApiConfig.Register);
            GlobalConfiguration.Configure(WebApiConfig.Format);
        }


        /*
         Para não termos problemas com as chamadas cross-origin (de servidores diferentes) e com cabeçalhos de autorização, 
         deve-se habilitar o CORs e outras permissões de cabeçalhos, inclusive o cabeçalho Authorization usado para enviar o 
         token de acesso. Isso é feito em Global.asax.
             */
        /*protected void Application_BeginRequest(object sender, EventArgs e)
        {
            var origin = Context.Request.Headers["Origin"];
            if (string.IsNullOrWhiteSpace(origin))
                origin = "*";

            Context.Response.AddHeader("Access-Control-Allow-Origin", origin);
            Context.Response.AddHeader("Access-Control-Allow-Credentials", "true");
            Context.Response.AddHeader("Access-Control-Allow-Methods", "GET,HEAD,OPTIONS,POST,PUT,DELETE");
            Context.Response.AddHeader("Access-Control-Allow-Headers", "Access-Control-Allow-Headers, Origin, Accept, X-Requested-With, Content-Type, Access-Control-Request-Method, Access-Control-Request-Headers, Access-Control-Allow-Credentials, Authorization");

            if (Context.Request.HttpMethod != "OPTIONS")
                return;

            Context.Response.End();
        }*/
    }
}
