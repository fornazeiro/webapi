﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    //[Authorize]
    public class ClienteController : ApiController
    {
        List<Cliente> lista = new List<Cliente>();
        // GET: api/Cliente
        public List<Cliente> Get()
        {
            GeraListaCliente();

            return lista;
        }

        // GET: api/Cliente/5
        public Cliente Get(int id)
        {
            GeraListaCliente();

            return lista.Where(x => x.Id == id).FirstOrDefault();
        }

        // POST: api/Cliente
        public IHttpActionResult Post([FromBody]Cliente value)
        {
            GeraListaCliente();

            try
            {
               lista.Add(value);
            }
            catch (Exception)
            {

                throw;
            }

            return Ok(lista);
        }

        // PUT: api/Cliente/5
        public IHttpActionResult Put(int id, [FromBody]Cliente value)
        {
            GeraListaCliente();

            try
            {
                var cliente = lista.Where(x => x.Id == id).FirstOrDefault();

                cliente = value;

                cliente.Id = value.Id;
                cliente.Nome = value.Nome;
                cliente.Sobrenome = value.Sobrenome;
                cliente.Nascimento = value.Nascimento;              
            }
            catch (Exception)
            {

                throw;
            }

            return Ok();
        }

        // DELETE: api/Cliente/5
        public IHttpActionResult Delete(int id)
        {
            try
            {
                if (id > 0)
                {
                    GeraListaCliente();

                    var del = lista.Where(x => x.Id == id).FirstOrDefault();

                    lista.Remove(del);
                }

                return Ok();
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void GeraListaCliente()
        {
            lista.Add(new Cliente
            {
                Id = 1,
                Nome = "Nelson",
                Sobrenome = "Fornazeiro",
                Nascimento = Convert.ToDateTime("13/03/1965")
            });
            lista.Add(new Cliente
            {
                Id = 2,
                Nome = "Regina",
                Sobrenome = "Fornazeiro",
                Nascimento = Convert.ToDateTime("10/11/1971")
            });
            lista.Add(new Cliente
            {
                Id = 3,
                Nome = "Daniel",
                Sobrenome = "Fornazeiro",
                Nascimento = Convert.ToDateTime("07/06/2006")
            });
            lista.Add(new Cliente
            {
                Id = 4,
                Nome = "Felipe",
                Sobrenome = "Fornazeiro",
                Nascimento = Convert.ToDateTime("27/01/2008")
            });
            lista.Add(new Cliente
            {
                Id = 5,
                Nome = "Marcos",
                Sobrenome = "Fornazeiro",
                Nascimento = Convert.ToDateTime("07/05/2013")
            });
        }
    }
}
