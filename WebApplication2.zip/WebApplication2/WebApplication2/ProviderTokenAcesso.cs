﻿using Microsoft.Owin.Security.OAuth;
using System.Security.Claims;
using System.Threading.Tasks;

namespace WebApplication2
{
    public class ProviderTokenAcesso : OAuthAuthorizationServerProvider
    {
        public override Task ValidateClientAuthentication(OAuthValidateClientAuthenticationContext context)
        {
            context.Validated();
            return Task.FromResult<object>(null);
        }

        public override async Task GrantResourceOwnerCredentials(OAuthGrantResourceOwnerCredentialsContext context)
        {
            //aqui fazemos a validacao das credencias do usuario
            if (context.UserName == "Nelson" && context.Password == "123")
            {
                var identity = new ClaimsIdentity(context.Options.AuthenticationType);
                identity.AddClaim(new Claim("sub", context.UserName));
                identity.AddClaim(new Claim("role", "user"));

                context.Validated(identity);
            }
            else
            {
                context.SetError("acesso inválido", "As credenciais do usuário não conferem....");
                return;
            }
        }
    }
}






/*
 * requisitar token e armazenar
 this.getAuthorizeToken = function () {
        $.ajax({
            "async": false,
            "crossDomain": true,
            "url": "http://localhost/AdaLovelaceApi/Token",
            "method": "POST",
            "headers": {
                "content-type": "application/x-www-form-urlencoded"
            },
            "xhrFields": {
                "withCredentials": true
            },
            "data": {
                "grant_type": "password"
            }
        }).done(function (data, textStatus, jqXHR) {
            sessionStorage.setItem("authToken", data.token_type + " " + data.access_token);
        }).fail(function (qXHR, textStatus, errorThrown) {
            console.log("error", "Usuario nao autorizado");
        });
    } 
    //enviar requisicao
    $.ajax({
    url: ajaxUrl,
    type: ajaxType,
    .
    .
    .
    headers: {
        "Authorization": sessionStorage.getItem("authToken")
    }
});
 */
/*
 var apiUrl = "https://appdomain.com/token"
var client = new HttpClient();    
client.Timeout = new TimeSpan(1, 0, 0);
           var loginData = new Dictionary<string, string>
               {
                   {"UserName", model.UserName},
                   {"Password", model.Password},
                   {"grant_type", "password"}
               };
           var content = new FormUrlEncodedContent(loginData);
           var response = client.PostAsync(apiUrl, content).Result;
    */
