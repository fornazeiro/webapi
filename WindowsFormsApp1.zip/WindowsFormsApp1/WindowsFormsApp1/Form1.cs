﻿using System;
using System.Net.Http;
using System.Text;
using System.Windows.Forms;



namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        
        private void Form1_Load(object sender, EventArgs e)
        {
            ObterToken();
        }

        private async void ObterToken()
        {
            Usuario user = new Usuario();
            user.username = "Nelson";
            user.password = "123";
            user.grant_type = "password";

            
            using (HttpClient client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:62798/");

                HttpResponseMessage response =
                  client.PostAsync("token",
                    new StringContent(string.Format("grant_type=password&username={0}&password={1}",
                      System.Net.WebUtility.UrlEncode(user.username),
                      System.Net.WebUtility.UrlEncode(user.password)), Encoding.UTF8,
                      "application/x-www-form-urlencoded")).Result;

                string resultJSON = response.Content.ReadAsStringAsync().Result;

                var token = Newtonsoft.Json.JsonConvert.DeserializeObject<Token>(resultJSON);

            }

            //var tk = Newtonsoft.Json.JsonConvert.SerializeObject(user);

            //var ct = GetObjectContent(data);

            //client.BaseAddress = new Uri("http://localhost:62798/");

            //var response = await client.SendAsync(new HttpRequestMessage(HttpMethod.Post, "token") { Content = GetObjectContent(data) }, CancellationToken.None);
            //var result = await response.Content.ReadAsAsync<dynamic>();
            //var resposta = await client.SendAsync("", GetObjectContent(user));
        }

        public class Cliente
        {
            public int Id { get; set; }
            public string Nome { get; set; }
            public string Sobrenome { get; set; }
            public DateTime Nascimento { get; set; }
        }

        public class Usuario
        {
            public string username { get; set; }
            public string password { get; set; }
            public string grant_type { get; set; }
        }

        public class Token
        {
            public string access_token { get; set; }
            public string token_type { get; set; }
            public string expires_in { get; set; }
        }
    }
}
